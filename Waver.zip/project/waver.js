let cartCount = 0;

function addToCart() {
    cartCount++;
    updateCartDisplay("Product added to your cart!");
}

function removeFromCart() {
    if (cartCount > 0) {
        cartCount--;
        updateCartDisplay("Product removed from your cart!");
    }
}

function updateCartDisplay(message) {
    const cartCountElement = document.getElementById('cartCount');
    cartCountElement.innerText = cartCount;

    cartCountElement.style.display = cartCount > 0 ? 'inline-block' : 'none';
    const popup = document.getElementById('popupMessage');
    popup.innerText = message;
    popup.style.display = 'block';
    setTimeout(() => {
        popup.style.display = 'none';
    }, 2000);
}

const addToCartButtons = document.querySelectorAll('.addToCartButton');
addToCartButtons.forEach(button => {
    button.addEventListener('click', addToCart);
});

document.getElementById('removeFromCartButton').addEventListener('click', removeFromCart);

window.addEventListener("scroll", function() {
    const navbar = document.getElementById("navbar");
    const description = document.getElementById("description");

    // Apply blur effect when scrolled beyond 50px
    if (window.scrollY > 50) {
        navbar.classList.add("scrolled");
    } else {
        navbar.classList.remove("scrolled");
    }
});
